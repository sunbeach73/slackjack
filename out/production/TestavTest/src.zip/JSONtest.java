import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class JSONtest {

    public static void main(String[] args) {

        JSONParser parser = new JSONParser();

        try {
            Object obj = parser.parse(new FileReader("C:\\Frode\\cards.json"));

            JSONArray JaO = (JSONArray) obj;
            System.out.println(JaO);
            JSONObject jo = (JSONObject)((JSONArray) obj).get(1);

            BJCard AA = new BJCard();
            BJDeck BB = new BJDeck();
            String temp;

            for (int i = 0; i < ((JSONArray) obj).size(); i++) {

                jo = (JSONObject)((JSONArray) obj).get(i);
                ((BJCard) AA).BJSuit = (String) jo.get("suit");
                ((BJCard) AA).BJValue = (String) jo.get("value");;
                System.out.println(((BJCard) AA).BJSuit);
                System.out.println(((BJCard) AA).BJValue);
                BB.Deck.add(AA);

//                ((BJDeck) BB).Deck.add(AA);
//                System.out.println(JaO.get(i));
            }

            /**            // Lager object BJ Deck og bruker metoden getBJValue i den
            Object A = new BJDeck();
            Integer ttteee = ((BJHand) A).getBJValue();
            System.out.println(ttteee);*/

            System.out.println("----------------------");
            System.out.println(((BJDeck) BB).Deck.size());

            BJCard CC = new BJCard();
            CC = BB.Deck.get(3);

            //System.out.println(((BJDeck) BB).Deck.get(2).BJSuit);
            //System.out.println(((BJDeck) BB).Deck.get(2).BJValue);
            //System.out.println(((BJDeck) BB).Deck.get(1));
            System.out.println(CC.BJSuit);
            System.out.println(CC.BJValue);


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

    }

}


/**            Object obj = parser.parse(new InputStreamReader(is));*/
    /**FileReader("C:\\Frode\\cards.json"));*/
    /**JSONObject object = JSONParser.getJSONFromUrl("http://nav-deckofcards.herokuapp.com/shuffle.json");*/
    /**JSONArray jsonObjects = (JSONArray) obj;
     JSONObject jo = (JSONObject)((JSONArray) obj).get(1);
     /**System.out.println(jsonObject);
     System.out.println(((JSONArray) obj).size());
     System.out.println(((JSONArray) obj).toJSONString());
     System.out.println(((JSONArray) obj).subList(1,5));*/
/**    String suit;
    String value;
    Integer gamevalue ;
*/
/**for (int i = 0; i < ((JSONArray) obj).size(); i++) {
 jo = (JSONObject) jsonObjects.get(i);
 suit = (String) jo.get("suit");
 value = (String) jo.get("value");

 if ((value.equals("J"))||(value.equals("Q"))||(value.equals("K")))
 {
 gamevalue  = 10;
 }
 else if (value.equals("A"))
 {
 gamevalue = 11;
 }
 else
 {
 gamevalue  = Integer.parseInt(value);
 }
 System.out.println(suit + " " + value + " " + gamevalue ); /
 }*/
/**while (jsonObjects.get(i)!= null){
 System.out.println(jsonObjects.get(i));*/

/**i = i +1;*/


/**
public class JSONtest {
    public static void main(String[] args){

        JSONParser parser = new JSONParser();
        try
        {
            Object obj = parser.parse(new FileReader("C:\\Frode\\cards.txt"));


/**                    "http://nav-deckofcards.herokuapp.com/shuffle.json"));*

            String theFileName = "http://nav-deckofcards.herokuapp.com/shuffle.json";
            URL url = new URL(theFileName);
            BufferedReader inputStream = new BufferedReader(new InputStreamReader(url.openStream()));

            JSONObject jsonObject = (JSONObject) obj;

            String kort = (String) jsonObject.get("suit");
            String kort2 = (String) jsonObject.get("value");
            System.out.println(kort);
            System.out.println(kort2);

        }
        catch(FileNotFoundException fe)
        {
            fe.printStackTrace();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

    }
}

*/
/**
URL cards = new URL("http://nav-deckofcards.herokuapp.com/shuffle.json");
    URLConnection yc = cards.openConnection();
    BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
    String inputLine;
            while ((inputLine = in.readLine()) != null) {
                    JSONArray obj = (JSONArray) parser.parse(inputLine);
                    /**for (Object o : obj) {
                     JSONObject xxx = (JSONObject) o;
                     System.out.println(xxx.get("value"));
                     }
                    }
                    System.out.println(inputLine);
*/