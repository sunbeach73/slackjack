import java.util.ArrayList;

public class BJDeck {

    ArrayList<BJCard> Deck = new ArrayList<BJCard>();

}
