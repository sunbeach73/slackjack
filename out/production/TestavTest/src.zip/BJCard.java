public class BJCard {
    String BJSuit;
    String BJValue;
}
