import java.util.ArrayList;

public class BJHand {

    ArrayList<BJCard> BJHand = new ArrayList<BJCard>();

    public int getBJValue() {
        // ...
        return 1;
    }


//return BJHand;
}
